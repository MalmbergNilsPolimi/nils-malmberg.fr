//
// u2-dessin.cpp
// Declarations externes - inclusion des fichiers d'entete
// Librairies standards
#include <iostream>   // cin, cout, ...
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
// Librairies fltk
#include <FL/Fl.H>
#include <FL/fl_draw.H>     // fonctions de dessin
#include <FL/Fl_BMP_Image.H>
#include <FL/Fl_Scrollbar.H>
// Programmes locaux
#include "u1-interface.h"
#include "u2-dessin.h"
#include "u4-fonctions.h"

// Declaration pour utiliser iostream
using namespace std;

// DESSIN : NILS MALMBERG

// DessinerZone
void ZoneDessinDessinerCB( Fl_Widget* widget, void* data)
{
    // On efface toute la zone ( en dessinant dessus un rectangle plein, blanc )
    fl_color(FL_WHITE);
    fl_rectf(X_ZONE,Y_ZONE,L_ZONE - 2*COTE + 4,H_ZONE);

    // On dessine les cases
    int l,c;
    for (l=0; l < gDonnees.nbqbits*pow(2,gDonnees.nbqbits); l++)
    {
        // Dessin des etats de base
        fl_color(FL_BLACK);
        char k[15];

        sprintf(k, "%c%d%c", '|', gDonnees.tab_etat_base[l], '>');

        fl_draw(k, X_ZONE + 10,Y_ZONE + 35 + l*1.5*COTE); // dessins kets

        // Dessin tenseurs
        if(l%gDonnees.nbqbits != 0){
                fl_color(FL_RED);
                fl_circle(X_ZONE + 18, Y_ZONE + 8 + l*1.5*COTE,  RAYON);
                fl_line(X_ZONE + 13, 23 + l*1.5*COTE, X_ZONE + 13 + 10, 13 + l*1.5*COTE);
                fl_line(X_ZONE + 13 + 10, 23 + l*1.5*COTE, X_ZONE + 13, 13 + l*1.5*COTE);
            }

        for (c=0; c < gDonnees.nb_colonnes; c++)
        {
            //Dessin des cases bleues
            fl_color(FL_BLUE);
            fl_rect(X_ZONE + 50 + c*1.5*COTE, Y_ZONE + 10 + l*1.5*COTE, 1.25*COTE,1.25*COTE);
        }
    }

    int ligne,colonne;

    for (ligne=0; ligne <gDonnees.nbqbits*pow(2,gDonnees.nbqbits); ligne++)
    {

        for (colonne=0; colonne < gDonnees.nb_colonnes; colonne++)
        {
            if(gDonnees.XClic >= X_ZONE + 50 + colonne*1.5*COTE && gDonnees.XClic <= X_ZONE + 50 + colonne*1.5*COTE + 1.25*COTE)
            {
                if(gDonnees.YClic >= Y_ZONE + 10 + ligne*1.5*COTE && gDonnees.YClic <= Y_ZONE + 10 + ligne*1.5*COTE + 1.25*COTE)
                {
                    gDonnees.tab_op_use[ligne][colonne] = gDonnees.op_select; // stockage operateur selectionne et stockage coordonne
                    //cout<< gDonnees.tab_op_use[ligne][colonne] <<endl;
                }
            }
        }
    }

    int i,j;

    for(i = 0; i < gDonnees.nbqbits*pow(2,gDonnees.nbqbits); i++)
    {
        for(j = 0; j < gDonnees.nb_colonnes; j++)
        {
            if(gDonnees.tab_op_use[i][j] != 'D')
            {
                fl_color(FL_RED);
                char w[2];
                sprintf(w, "%c",gDonnees.tab_op_use[i][j]);
                //cout << c <<endl;
                fl_draw(w, X_ZONE + 47 + j*1.5*COTE + 1.25*COTE/2.0, Y_ZONE + 16 + i*1.5*COTE + 1.25*COTE/2.0); // affichage sur interface des portes quantiques
            }
        }
    }
}

void ZoneOperateursCB( Fl_Widget* w, void* data)
{
    // On efface toute la zone ( en dessinant dessus un rectangle plein, blanc )
    fl_color(FL_WHITE);
    fl_rectf(X_ZONE + L_ZONE - 2*COTE + 8, Y_ZONE, 2*COTE + 2,H_ZONE);

    // On dessine la liste des operateurs disponibles
    ChoisirOperateur(0) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3,1.25*COTE,1.25*COTE);
    fl_draw("..",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 8,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(1) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("X",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 8 + 1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(2) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 2*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("..",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 8 + 2*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(3) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 3*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("Z",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 10 + 3*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(4) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 4*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("H",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 11 + 4*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(5) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 5*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("S",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 12 + 5*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(6) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 6*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("T",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 13 + 6*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(7) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 7*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("NOT",X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 13 + 7*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(8) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 8*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("..",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 13 + 8*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(9) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 9*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("..",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 13 + 9*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(10) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 10*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("..",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 13 + 10*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(11) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 11*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("..",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 13 + 11*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    ChoisirOperateur(12) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 12*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_draw("..",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 13 + 12*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);

    //Porte controle
    ChoisirOperateur(13) ;
    fl_rect(X_ZONE + L_ZONE - 2*COTE + 20, Y_ZONE + 3 + 13*1.3*COTE,1.25*COTE,1.25*COTE);
    fl_pie(X_ZONE + L_ZONE - 2*COTE + 33, Y_ZONE + 38 + 13*1.25*COTE,10,10,0,360);

    ChoisirOperateur(14) ;
    fl_draw("Delete",X_ZONE + L_ZONE - 2*COTE + 16, Y_ZONE + 27 + 14*1.25*COTE,1.25*COTE,1.25*COTE, FL_ALIGN_CENTER);
}

// Correspondance numero de pion avec couleur associee, sert au dessin des pions du jeu
void ChoisirOperateur(int Operateur)
{
    switch (Operateur) {

        case 0 :
            fl_color(FL_BLACK);
            break;
        case 1 :
            fl_color(FL_BLACK);
            break;
        case 2 :
            fl_color(FL_BLACK);
            break;
        case 3 :
            fl_color(FL_BLACK);
            break;
        case 4 :
            fl_color(FL_BLACK);
            break;
        case 5 :
            fl_color(FL_BLACK);
            break;
        case 6 :
            fl_color(FL_BLACK);
            break;
        case 7 :
            fl_color(FL_BLACK);
            break;
        case 8 :
            fl_color(FL_BLACK);
            break;
        case 9 :
            fl_color(FL_BLACK);
            break;
        case 10 :
            fl_color(FL_BLACK);
            break;
        case 11 :
            fl_color(FL_BLACK);
            break;
        case 12 :
            fl_color(FL_BLACK);
            break;
        case 13 :
            fl_color(FL_BLACK);
            break;
        case 14 :
            fl_color(FL_BLACK);
            break;
    }
}

void ZoneProbaCB(Fl_Widget* w, void* data)
{
    // Affichage valeurs probabilites initiales
    fl_color(FL_WHITE);
    fl_rectf(10,10,680,45);
        for(int i = 0; i < pow(2,gDonnees.nbqbits); i++)
    {
        fl_color(FL_BLUE);
        char val[15];
        sprintf(val, "%.3lf", pow(fabs(gDonnees.coeff_init_norme[i]),2));
        fl_draw(val, i*680.0/(2*gDonnees.nbqbits) + 70, 35);
    }
}

void ZoneProbaFinCB(Fl_Widget* w, void* data)
{
    // Affichage valeurs probabilites finales
    fl_color(FL_WHITE);
    fl_rectf(10,10,680,45);
        for(int i = 0; i < pow(2,gDonnees.nbqbits); i++)
    {
        fl_color(FL_BLUE);
        char val[15];
        sprintf(val, "%.3lf", pow(fabs(gDonnees.coeff_fin_norme[i]),2));
        fl_draw(val, i*680.0/(2*gDonnees.nbqbits) + 70, 35);
    }
}

void ZoneNormeCB(Fl_Widget* w, void* data)
{
    // Affichage des valeurs des normes initiales
    fl_color(FL_WHITE);
    fl_rectf(10,10,680,45);
        for(int i = 0; i < pow(2,gDonnees.nbqbits); i++)
    {
        fl_color(FL_BLUE);
        char val[15];
        sprintf(val, "%.3lf", gDonnees.coeff_init_norme[i]);
        fl_draw(val, i*680.0/(2*gDonnees.nbqbits) + 70, 35);
    }
}

void ZoneLogoCB( Fl_Widget* widget, void* data )
{
    // Optionnel : affichage du logo du projet
    Fl_BMP_Image ImageLogoPhelma("media/logoprojet.bmp") ;
    ImageLogoPhelma.draw(X_ZONE_LOGO, Y_ZONE_LOGO);
}
