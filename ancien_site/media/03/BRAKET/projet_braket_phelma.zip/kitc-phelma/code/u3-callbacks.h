//
// u3-callbacks.h
// Sentinelle d'inclusion
#ifndef _u3_callbacks_h
#define _u3_callbacks_h

// Declarations externes
#include <FL/Fl_Widget.H>

#define COTE 30

// Declaration des sous-programmes
void TraiterCycleCB() ;

void ZoneDessinSourisCB( Fl_Widget* widget, void* data ) ;
void ZoneDessinClavierCB( Fl_Widget* widget, void* data ) ;
void ZoneOperateursSourisCB( Fl_Widget* widget, void* data ) ;

void ChampNbQbitsCB(Fl_Widget* w, void* data) ;
void BoutonOkNbQbitsCB(Fl_Widget* w, void* data) ;

void BoutonImportCB(Fl_Widget* w, void* data) ;
void ChampSaisieCoeffCB(Fl_Widget* w, void* data) ;
void BoutonOkImportMainCB(Fl_Widget* w, void* data) ;

void BoutonCalculNormeCB(Fl_Widget* w, void* data) ;
void BoutonCloseNormeCB(Fl_Widget* w, void* data) ;

void BoutonCalculProbaCB( Fl_Widget* w, void* data) ;
void BoutonCloseProbaCB(Fl_Widget* w, void* data) ;
void BoutonCalculProbaFinCB( Fl_Widget* w, void* data) ;
void BoutonCloseProbaFinCB(Fl_Widget* w, void* data) ;

void BoutonSaveCB(Fl_Widget* w, void* data) ;
void ChampSaisieTxtCB(Fl_Widget* w, void* data) ;
void BoutonOkSaveCB(Fl_Widget* w, void* data) ;

void BoutonAideCB(Fl_Widget* w, void* data) ;
void BoutonQuitterCB( Fl_Widget* w, void* data ) ;


#endif // _u3_callbacks_h
