//
// u4-fonctions.cpp
// Declarations externes - inclusion des fichiers d'entete
// Librairies standards
#include <iostream>     // cout, cin, ...
#include <stdlib.h>     // exit, rand
#include <time.h>       // time
#include <string.h>     // strcpy
#include <math.h>
#include <complex.h>
#include <stdio.h>

// Librairie fmod pour le son
#include <api/inc/fmod.h>
#include <api/inc/fmod_errors.h>
// Programmes locaux
#include "u1-interface.h"
#include "u4-fonctions.h"

// Declaration pour utiliser iostream
using namespace std;

// Definition des donnees fonctionnelles du projet - structure globale de variables
struct Donnees gDonnees;

// Fonction initialisant les parametres et variables importants

// NILS MALMBERG

void InitialiserDonnees()
{
    gDonnees.nb_colonnes = 10; // nombre d operateur pouvant etre mis sur une ligne (limite par l affichage)

    gDonnees.tab_coeff_init = allouer_tab_char(pow(2,gDonnees.nbqbits));
    gDonnees.coeff_init = allouer_tab_double(pow(2,gDonnees.nbqbits));
    gDonnees.coeff_init_norme = allouer_tab_double(pow(2,gDonnees.nbqbits));
    gDonnees.coeff_fin = allouer_tab_double(pow(2,gDonnees.nbqbits));
    gDonnees.coeff_fin_norme = allouer_tab_double(pow(2,gDonnees.nbqbits));

    etat_de_base();
    etat_calcul();

    //definition lettres associes aux operateurs
    gDonnees.tab_op_def[0] = 'M';
    gDonnees.tab_op_def[1] = 'X';
    gDonnees.tab_op_def[2] = 'Y';
    gDonnees.tab_op_def[3] = 'Z';
    gDonnees.tab_op_def[4] = 'H';
    gDonnees.tab_op_def[5] = 'S';
    gDonnees.tab_op_def[6] = 'T';
    gDonnees.tab_op_def[7] = 'N';
    gDonnees.tab_op_def[8] = '1';
    gDonnees.tab_op_def[9] = '2';
    gDonnees.tab_op_def[10] = '3';
    gDonnees.tab_op_def[11] = '4';
    gDonnees.tab_op_def[12] = '5';
    gDonnees.tab_op_def[13] = 'C';
    gDonnees.tab_op_def[14] = 'D';

    // definition des portes quantiques
    gDonnees.X = allouer_mat_float(2);
    gDonnees.X[0][0] = 0;
    gDonnees.X[0][1] = 1;
    gDonnees.X[1][0] = 1;
    gDonnees.X[1][1] = 0;

    gDonnees.Y = allouer_mat_cpxfloat(2);
    gDonnees.Y[0][0] = 0;
    gDonnees.Y[0][1] = -1.0*I;
    gDonnees.Y[1][0] = 1.0*I;
    gDonnees.Y[1][1] = 0;

    gDonnees.Z = allouer_mat_float(2);
    gDonnees.Z[0][0] = 1;
    gDonnees.Z[0][1] = 0;
    gDonnees.Z[1][0] = 0;
    gDonnees.Z[1][1] = -1;

    gDonnees.H = allouer_mat_float(2);
    gDonnees.H[0][0] = 1.0/pow(2,0.5);
    gDonnees.H[0][1] = 1.0/pow(2,0.5);
    gDonnees.H[1][0] = 1.0/pow(2,0.5);
    gDonnees.H[1][1] = -1.0/pow(2,0.5);

    gDonnees.S = allouer_mat_float(4);
    gDonnees.S[0][0] = 1;
    gDonnees.S[0][1] = 0;
    gDonnees.S[0][2] = 0;
    gDonnees.S[0][3] = 0;
    gDonnees.S[1][0] = 0;
    gDonnees.S[1][1] = 0;
    gDonnees.S[1][2] = 1;
    gDonnees.S[1][3] = 0;
    gDonnees.S[2][0] = 0;
    gDonnees.S[2][1] = 1;
    gDonnees.S[2][2] = 0;
    gDonnees.S[2][3] = 0;
    gDonnees.S[3][0] = 0;
    gDonnees.S[3][1] = 0;
    gDonnees.S[3][2] = 0;
    gDonnees.S[3][3] = 0;

    gDonnees.CN = allouer_mat_float(4);
    gDonnees.CN[0][0] = 1;
    gDonnees.CN[0][1] = 0;
    gDonnees.CN[0][2] = 0;
    gDonnees.CN[0][3] = 0;
    gDonnees.CN[1][0] = 0;
    gDonnees.CN[1][1] = 1;
    gDonnees.CN[1][2] = 0;
    gDonnees.CN[1][3] = 0;
    gDonnees.CN[2][0] = 0;
    gDonnees.CN[2][1] = 0;
    gDonnees.CN[2][2] = 0;
    gDonnees.CN[2][3] = 1;
    gDonnees.CN[3][0] = 0;
    gDonnees.CN[3][1] = 0;
    gDonnees.CN[3][2] = 1;
    gDonnees.CN[3][3] = 0;

    // Initialisation du tableau de portes utilises
    // D = lettre pour supprimer un operateur donc lors du calcul la presence d un D voudra dire qu il n y a pas de calcul a faire
    gDonnees.tab_op_use = allouer_mat_char_op_use();
    int ligne,colonne;
    for(ligne = 0; ligne < gDonnees.nbqbits*pow(2,gDonnees.nbqbits); ligne++)
    {
        for(colonne = 0; colonne < gDonnees.nb_colonnes; colonne++)
        {
            gDonnees.tab_op_use[ligne][colonne] = 'D';
        }
    }

}


// Fonctions utilitaires

// Fonctions d allocation de tableaux et matrices pour differents types

// ALLOCATION : MAXIME MOSHFEGHI ET CHARLOTTE LANGELLA

char* allouer_tab_char(int n)
{
    char* tab = (char*)calloc(n, sizeof(tab));
    return tab;
}

int* allouer_tab_int(int n)
{
    int* tab = (int*)calloc(n, sizeof(tab));
    return tab;
}

double* allouer_tab_double(int n)
{
    double* tab = (double*)calloc(n, sizeof(tab));
    return tab;
}

char** allouer_mat_char_op_use()
{
    int i;
    char** tab;
    tab = (char**)calloc(gDonnees.nb_colonnes, sizeof(*tab));

    if (tab == NULL)
    {
        return NULL;
    }
    else
    {
        for(i = 0; i < gDonnees.nb_colonnes; i++)
        {
            tab[i] = (char*)calloc(gDonnees.nbqbits*pow(2,gDonnees.nbqbits), sizeof(**tab));
            if (tab[i] == NULL)
            {
                return NULL;
            }
        }
    }
    return tab;
}

int** allouer_mat_int(int n)
{
    int i;
    int** tab;
    tab = (int**)calloc(pow(2,n), sizeof(*tab));

    if (tab == NULL)
    {
        return NULL;
    }
    else
    {
        for(i = 0; i < pow(2,n); i++)
        {
            tab[i] = (int*)calloc(n, sizeof(**tab));
            if (tab[i] == NULL)
            {
                return NULL;
            }
        }
    }
    return tab;
}

double** allouer_mat_double(int n)
{
    int i;
    double** tab;
    tab = (double**)calloc(pow(2,n), sizeof(*tab));

    if (tab == NULL)
    {
        return NULL;
    }
    else
    {
        for(i = 0; i < pow(2,n); i++)
        {
            tab[i] = (double*)calloc(n, sizeof(**tab));
            if (tab[i] == NULL)
            {
                return NULL;
            }
        }
    }
    return tab;
}

double** allouer_matcol_double(int n)
{
    int i;
    double** tab;
    tab = (double**)calloc(pow(2,n), sizeof(*tab));

    if (tab == NULL)
    {
        return NULL;
    }
    else
    {
        for(i = 0; i < pow(2,n); i++)
        {
            tab[i] = (double*)calloc(1, sizeof(**tab));
            if (tab[i] == NULL)
            {
                return NULL;
            }
        }
    }
    return tab;
}

float** allouer_mat_float(int n)
{
    int i;
    float** tab;
    tab = (float**)calloc(pow(2,n), sizeof(*tab));

    if (tab == NULL)
    {
        return NULL;
    }
    else
    {
        for(i = 0; i < pow(2,n); i++)
        {
            tab[i] = (float*)calloc(n, sizeof(**tab));
            if (tab[i] == NULL)
            {
                return NULL;
            }
        }
    }
    return tab;
}

float __complex__** allouer_mat_cpxfloat(int n)
{
    int i;
    float __complex__** tab;
    tab = (float __complex__**)calloc(pow(2,n), sizeof(*tab));

    if (tab == NULL)
    {
        return NULL;
    }
    else
    {
        for(i = 0; i < pow(2,n); i++)
        {
            tab[i] = (float __complex__*)calloc(n, sizeof(**tab));
            if (tab[i] == NULL)
            {
                return NULL;
            }
        }
    }
    return tab;
}

// Definition des kets 0 1 pour 1qbit 00 01 10 11 pour deux qbits
// Sert a l affichage pour les graphiques et la zone de dessin principale

// ETATS : MATIAS MIRANDA

void etat_de_base()
 {
    gDonnees.tab_etat_base = allouer_tab_int(gDonnees.nbqbits*pow(2, gDonnees.nbqbits));

    if(gDonnees.nbqbits == 1)
    {
        gDonnees.tab_etat_base[0] = 0;
        gDonnees.tab_etat_base[1] = 1;
    }
    else if(gDonnees.nbqbits == 2)
    {
        gDonnees.tab_etat_base[0] = 0;
        gDonnees.tab_etat_base[1] = 0;
        gDonnees.tab_etat_base[2] = 0;
        gDonnees.tab_etat_base[3] = 1;
        gDonnees.tab_etat_base[4] = 1;
        gDonnees.tab_etat_base[5] = 0;
        gDonnees.tab_etat_base[6] = 1;
        gDonnees.tab_etat_base[7] = 1;
    }
 }

 // Definition du produit tensoriel pour des vecteurs de dimension 4 soit 2 qbits

 // MATIAS MIRANDA

 double* produit_tensoriel(double* etat1, double* etat2)
 {
     double* produit = allouer_tab_double(pow(2,gDonnees.nbqbits));
     produit[0] = etat1[0]*etat2[0];
     produit[1] = etat1[0]*etat2[1];
     produit[2] = etat1[1]*etat2[0];
     produit[3] = etat1[1]*etat2[1];

     return produit;
 }

// Fonction permettant de sauvegarder les resultats

// MAXIME MOSHFEGHI ET CHARLOTTE LANGELLA

void sauvegarder(char* nom)
{
    FILE* fichier = NULL ;

    fichier = fopen(nom, "wt") ;

    if (fichier != NULL){
        int i = 0 ;
        fputs("\t \t \t \t \t", fichier);
        for(i; i < pow(2,gDonnees.nbqbits); i++)
        {
            char k[15];
            if(gDonnees.nbqbits == 1)
            {
                sprintf(k, "%c%d%c", '|', gDonnees.tab_etat_base[i], '>');
            }
            else if(gDonnees.nbqbits == 2)
            {
                sprintf(k, "%c%d%d%c", '|', gDonnees.tab_etat_base[2*i], gDonnees.tab_etat_base[2*i + 1], '>');
            }
            fprintf(fichier, "%s\t \t", k);
        }

        fputs("\n", fichier);
        i = 0;
        char* s1 = "Coefficients initiaux normes";
        fprintf(fichier, "%s\t", s1);
        while(i < pow(2,gDonnees.nbqbits)){
            fprintf(fichier, "%5.4lf\t",gDonnees.coeff_init_norme[i]);
            i++ ;
        }
        fputs("\n", fichier) ;
        i = 0 ;
        char* s2 = "Coefficients finaux normes";
        fprintf(fichier, "%s\t", s2);
        while(i < pow(2,gDonnees.nbqbits)){
            fprintf(fichier, "%5.4lf\t",gDonnees.coeff_fin_norme[i]);
            i++ ;
        }
        fputs("\n", fichier) ;
        char* s3 = "Probabilites finales";
        fprintf(fichier, "%s\t \t", s3);
        i = 0 ;
        double proba ;
        while(i < pow(2,gDonnees.nbqbits)){
            proba = pow(gDonnees.coeff_fin_norme[i], 2) ;
            fprintf(fichier, "%5.4lf\t", proba) ;
            i++ ;
        }
    fputs("\n", fichier) ;
    }
    else {
        printf("Probleme de sauvegarde du fichier \n") ;
    }
    fclose(fichier) ;
}

// Lecture d un fichier texte et stockage des coefficients

// MAXIME MOSHFEGHI ET CHARLOTTE LANGELLA

void lecture_coeff(char* nomfichier){
    FILE * fichier = fopen(nomfichier, "rt") ;
    if (fichier != NULL){
        double val;
        int i = 0;
        while(fscanf(fichier,"%lf", &val)==1)
        {
            gDonnees.coeff_init[i] = val;
            i++;
        }
    }
    else {
        printf("Probleme de sauvegarde du fichier \n") ;
    }

    fclose(fichier) ;
}

// MATIAS MIRANDA

void produitmatriciel(int n, float** porte, double* vecteur) {
    int i = 0;
    int j = 0;
    double* s;
    s = (double*)calloc(n,sizeof(s));
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            s[i]+=vecteur[j] * porte[i][j];
        }

    }
    for (i=0; i < n; i++)
    {
        vecteur[i]=s[i];
    }
}

// NILS MALMBERG

void produitmatricielcplx(float __complex__** porte, float __complex__* vecteur)
{
    int i = 0;
    int j = 0;
    float __complex__* s;
    s = (float __complex__*)calloc(2,sizeof(s));
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            s[i]+=vecteur[j] * porte[i][j];
        }
    }
    for (i=0; i < 2; i++)
    {
        vecteur[i]=s[i];
    }
}

// Decomposition kets
// 1qbit 0 = (1 0) 1 = (0 1)
// 2 qbits 00 = (1 0) x (1 0) 01 = (1 0) x (0 1)...
// avec x le produit tensoriel

// MATIAS MIRANDA

void etat_calcul() {
    int i = 0;
    gDonnees.v = (double**)calloc(gDonnees.nbqbits*pow(2,gDonnees.nbqbits), sizeof(*gDonnees.v));
    for (i = 0; i < gDonnees.nbqbits*pow(2,gDonnees.nbqbits); i++)
    {
        gDonnees.v[i]= (double*)calloc(2, sizeof(**gDonnees.v));
    }
    if (gDonnees.nbqbits == 1)
    {
        gDonnees.v[0][0]= 1;
        gDonnees.v[0][1]= 0;
        gDonnees.v[1][0]= 0;
        gDonnees.v[1][1]= 1;
    }
    if (gDonnees.nbqbits == 2)
    {
        gDonnees.v[0][0]= 1;
        gDonnees.v[0][1]= 0;
        gDonnees.v[1][0]= 1;
        gDonnees.v[1][1]= 0;
        gDonnees.v[2][0]= 1;
        gDonnees.v[2][1]= 0;
        gDonnees.v[3][0]= 0;
        gDonnees.v[3][1]= 1;
        gDonnees.v[4][0]= 0;
        gDonnees.v[4][1]= 1;
        gDonnees.v[5][0]= 1;
        gDonnees.v[5][1]= 0;
        gDonnees.v[6][0]= 0;
        gDonnees.v[6][1]= 1;
        gDonnees.v[7][0]= 0;
        gDonnees.v[7][1]= 1;
    }
}

// MATIAS MIRANDA
void fct_swap(int i, double** vecteur){

    if(i%2 == 0)
    {
        gDonnees.prod = produit_tensoriel(vecteur[i], vecteur[i+1]);
        produitmatriciel(4, gDonnees.S, gDonnees.prod);
    }
    else
    {
        gDonnees.prod = produit_tensoriel(vecteur[i], vecteur[i-1]);
        produitmatriciel(4, gDonnees.S, gDonnees.prod);
    }
}

//Fonction parcourant la matrice des portes utilises et calculant le vecteur apres passage dans toutes les portes

// MATIAS MIRANDA ET NILS MALMBERG

void calcul_portes(double** vecteur)
{
    int i,j;
    for(j = 0; j < gDonnees.nb_colonnes; j++)
    {
        for(i = 0; i < gDonnees.nbqbits*pow(2,gDonnees.nbqbits) ; i++)
        {
            gDonnees.prod = allouer_tab_double(pow(2,gDonnees.nbqbits));
            switch(gDonnees.tab_op_use[i][j])
            {
                case 'S':
                    printf("S detected\n");

                    fct_swap(i, vecteur);

                    if(gDonnees.prod[0] == 1 && gDonnees.prod[1] == 0 && gDonnees.prod[2] == 0 && gDonnees.prod[3] == 0)
                    {
                        if(i%2 == 0)
                        {
                            vecteur[i][0] = 1;
                            vecteur[i][1] = 0;
                            vecteur[i+1][0] = 1;
                            vecteur[i+1][1] = 0;
                        }
                        else
                        {
                            vecteur[i][0] = 1;
                            vecteur[i][1] = 0;
                            vecteur[i-1][0] = 1;
                            vecteur[i-1][1] = 0;
                        }

                    }
                    else if(gDonnees.prod[0] == 0 && gDonnees.prod[1] == 1 && gDonnees.prod[2] == 0 && gDonnees.prod[3] == 0)
                    {
                        if(i%2 == 0)
                        {
                            vecteur[i][0] = 1;
                            vecteur[i][1] = 0;
                            vecteur[i+1][0] = 0;
                            vecteur[i+1][1] = 1;
                        }
                        else
                        {
                            vecteur[i][0] = 0;
                            vecteur[i][1] = 1;
                            vecteur[i-1][0] = 1;
                            vecteur[i-1][1] = 0;
                        }
                    }
                    else if(gDonnees.prod[0] == 0 && gDonnees.prod[1] == 0 && gDonnees.prod[2] == 1 && gDonnees.prod[3] == 0)
                    {
                        if(i%2 == 0)
                        {
                            vecteur[i][0] = 0;
                            vecteur[i][1] = 1;
                            vecteur[i+1][0] = 1;
                            vecteur[i+1][1] = 0;
                        }
                        else
                        {
                            vecteur[i][0] = 1;
                            vecteur[i][1] = 0;
                            vecteur[i-1][0] = 0;
                            vecteur[i-1][1] = 1;
                        }
                    }
                    else if(gDonnees.prod[0] == 0 && gDonnees.prod[1] == 0 && gDonnees.prod[2] == 0 && gDonnees.prod[3] == 1)
                    {
                        if(i%2 == 0)
                        {
                            vecteur[i][0] = 0;
                            vecteur[i][1] = 1;
                            vecteur[i+1][0] = 0;
                            vecteur[i+1][1] = 1;
                        }
                        else
                        {
                            vecteur[i][0] = 0;
                            vecteur[i][1] = 1;
                            vecteur[i-1][0] = 0;
                            vecteur[i-1][1] = 1;
                        }
                    }
                    break;

                case 'X':
                    printf("X detected\n");
                    //printf("Avant operation\n");
                    //printf("%lf\n", vecteur[i][0]);
                    //printf("%lf\n", vecteur[i][1]);
                    produitmatriciel(2 , gDonnees.X, vecteur[i]);
                    //printf("Apres operation\n");
                    //printf("%lf\n", vecteur[i][0]);
                    //printf("%lf\n", vecteur[i][1]);
                    break;

                case 'Y':
                    printf("Y detected\n");
                    //produitmatricielcplx(gDonnees.Y, vecteur[i]);
                    break;

                case 'Z':
                    printf("Z detected\n");
                    produitmatriciel(2, gDonnees.Z, vecteur[i]);
                    break;

                case 'H':
                    printf("H detected\n");
                    produitmatriciel(2, gDonnees.H, vecteur[i]);
                    break;

                case 'T':
                    printf("T detected\n");
                    //produitmatriciel(gDonnees.T, vecteur[i]);
                    break;

                case 'N':

                    if(i%2 == 0)
                    {
                        if(vecteur[i][0] == 0 && vecteur[i][1] == 1)
                        {
                            double s1, s2;
                            s1 = vecteur[i+1][0];
                            s2 = vecteur[i+1][1];
                            vecteur[i+1][0] = 1 - s1;
                            vecteur[i+1][1] = 1 - s2;
                        }
                    }
                    else
                    {
                        if(vecteur[i-1][0] == 0 && vecteur[i-1][1] == 1)
                        {
                            double s1, s2;
                            s1 = vecteur[i][0];
                            s2 = vecteur[i][1];
                            vecteur[i][0] = 1 - s1;
                            vecteur[i][1] = 1 - s2;
                        }
                    }
                    break;

                case 'D':
                    break;

                default :
                    break;
            }
        }
    }
}

// Fonction utilisant le vecteur final (apres passage dans les portes) et y applique les coefficients initiaux

// MATIAS MIRANDA ET NILS MALMBERG

void calcul_etat_final()
{
    if(gDonnees.nbqbits == 1)
    {
        calcul_portes(gDonnees.v);
        gDonnees.coeff_fin[0] = gDonnees.coeff_init_norme[0]*gDonnees.v[0][0] + gDonnees.coeff_init_norme[1]*gDonnees.v[1][0];
        gDonnees.coeff_fin[1] = gDonnees.coeff_init_norme[0]*gDonnees.v[0][1] + gDonnees.coeff_init_norme[1]*gDonnees.v[1][1];
    }
    else if(gDonnees.nbqbits == 2)
    {
        int i;
        double* prod1 = allouer_tab_double(pow(2,gDonnees.nbqbits));
        double* prod2 = allouer_tab_double(pow(2,gDonnees.nbqbits));
        double* prod3 = allouer_tab_double(pow(2,gDonnees.nbqbits));
        double* prod4 = allouer_tab_double(pow(2,gDonnees.nbqbits));

        calcul_portes(gDonnees.v);

        prod1 = produit_tensoriel(gDonnees.v[0], gDonnees.v[1]);
        prod2 = produit_tensoriel(gDonnees.v[2], gDonnees.v[3]);
        prod3 = produit_tensoriel(gDonnees.v[4], gDonnees.v[5]);
        prod4 = produit_tensoriel(gDonnees.v[6], gDonnees.v[7]);

        for(i = 0; i < pow(2, gDonnees.nbqbits); i++)
        {
            //printf("%lf\n", prod1[i]);
            gDonnees.coeff_fin[i] = gDonnees.coeff_init_norme[0]*prod1[i] + gDonnees.coeff_init_norme[1]*prod2[i] + gDonnees.coeff_init_norme[2]*prod3[i] + gDonnees.coeff_init_norme[3]*prod4[i];
            printf("%lf\n", gDonnees.coeff_fin[i]);
        }
    }

}

