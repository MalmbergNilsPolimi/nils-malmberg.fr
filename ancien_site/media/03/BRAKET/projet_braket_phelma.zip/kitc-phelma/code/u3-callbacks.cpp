//
// u3-callbacks.cpp
// Declarations externes - inclusion des fichiers d'entete
// Librairies standards
#include <iostream>     // cout, cin, ...
// Librairies fltk
#include <FL/Fl.H>
#include <FL/fl_ask.H>  // fl_message, fl_alert, fl_ask
#include <FL/Fl_File_Chooser.H> // fl_file_chooser
#include <FL/Fl_Help_Dialog.H>
#include <math.h>
// Programmes locaux
#include "u1-interface.h"
#include "u3-callbacks.h"
#include "u4-fonctions.h"

// Declaration pour utiliser iostream
using namespace std;

// CALLBACKS : NILS MALMBERG

// TraiterCycle
void TraiterCycleCB()
{
    // Trace pour bien montrer que la fonction est appelee cycliquement
    // printf(""Appel de TraiterCycleCB");

    // Traitements cycliques a placer ici :
    // ...

    // On redessine la zone
    gInterface.ZoneDessin->redraw() ;

    // Code a activer en cas de probleme pour saisir les evenements du clavier
    // Probleme : si les evenements du clavier ne sont pas bien pris en compte pour agir sur la zone de dessin.
    // Solution : On ramene systematiquement le focus des evenements sur la zone de dessin
    // Attention, cela peut perturber certains elements d'interface comme des champs de saisie texte ou numerique

    // Fl::focus(gInterface.ZoneDessin);

    // Fin code a activer en cas de probleme
}

// ZoneDessinSourisCB
void ZoneDessinSourisCB( Fl_Widget* widget, void* data )
{
 // ATTENTION : X et Y ne sont pas relatifs a la zone mais a la fenetre qui la contient !!!!

    // Exemple d'evenement : clic souris
    if ( Fl::event() == FL_PUSH )
    {
        gDonnees.nb_colonnes = 10;

        // Stockage des coordonnees des clics de souris
        gDonnees.XClic = Fl::event_x();
        gDonnees.YClic = Fl::event_y();

        printf("Mouse push operators = %i x = %i y = %i\n", Fl::event_button(), gDonnees.XClic, gDonnees.YClic);
    }
}

void ZoneOperateursSourisCB( Fl_Widget* widget, void* data )
{
    // ATTENTION : X et Y ne sont pas relatifs a la zone mais a la fenetre qui la contient !!!!
    // Exemple d'evenement : clic souris
    if ( Fl::event() == FL_PUSH )
    {
        int XOpClic = Fl::event_x();
        int YOpClic = Fl::event_y();
        int i;

        printf("Mouse push operators = %i x = %i y = %i\n", Fl::event_button(), XOpClic, YOpClic);

        // Determination et stockage des operateurs choisis en fonction des coordonnees du clic de la souris
        if( XOpClic >= X_ZONE + L_ZONE - 2*COTE + 8 && XOpClic <= X_ZONE + L_ZONE + 10){
            for(i = 0; i < 4; i++){
                if( YOpClic >= 13 + i*1.25*COTE && YOpClic <= 13 + (i+1)*1.25*COTE){
                    printf("%c\n", gDonnees.tab_op_def[i]);
                    gDonnees.op_select = gDonnees.tab_op_def[i];
                }
            }
            for(i = 4; i < 14; i++){
                if( YOpClic >= 15+i + i*1.25*COTE && YOpClic <= 15+ i+ 1 + (i+1)*1.25*COTE){
                    printf("%c\n", gDonnees.tab_op_def[i]);
                    gDonnees.op_select = gDonnees.tab_op_def[i];
                }
            }
            if(YOpClic >= 30 + 14*1.25*COTE && YOpClic <= H_ZONE + 30){
                printf("%c\n", gDonnees.tab_op_def[14]);
                gDonnees.op_select = gDonnees.tab_op_def[14];
            }
        }
    }
}



// ZoneDessinClavierCB
void ZoneDessinClavierCB( Fl_Widget* widget, void* data )
{

}

void ChampNbQbitsCB(Fl_Widget* w, void* data)
{
    gDonnees.nbqbits = gInterface.ChampNbQbits->value() ;
    if(gDonnees.nbqbits > 2){
        printf("Trop de Qubits : %d\n", gDonnees.nbqbits); // Securite afin de ne pas avoir de problemes d affichage et de calcul
        gDonnees.nbqbits = 0;
        fl_message("Entrez un entier inférieur à 2");
    } else printf("NbQubits : %d\n", gDonnees.nbqbits);
    InitialiserDonnees();// Initialisation lorsqu on connait le nombre de qbits
}

void BoutonOkNbQbitsCB(Fl_Widget* w, void* data)
{

}

// Choix de l importation main ou fichier
void BoutonImportCB(Fl_Widget* w, void* data)
{
    int choix = gInterface.BoutonImport->value();
    switch (choix)
    {
        case 0 :
            printf("Import : A la main\n");
            CreerInterfaceImportMain();
            break;
        case 1 :
            printf("Import : Via fichier\n");
            char* file = fl_file_chooser( "Fichier import", "*.{txt,dat}", NULL ); // choix du fichier
            if ( file != NULL )
            {
                printf("Fichier import : %s\n", file);
                lecture_coeff(file); // lecture du fichier et sauvegarde des coeffcients
            }
            break;
    }
}

void ChampSaisieCoeffCB(Fl_Widget* w, void* data)
{
    int i = 0;
    char* SaisieCoeff = allouer_tab_char(2*pow(2,gDonnees.nbqbits));
    strcpy(SaisieCoeff, gInterface.ChampSaisieCoeff->value()) ;//chaine de caracteres contenant les coefficients
    //printf("ChampCoeffCB : %s\n", *SaisieCoeff);

    while(*SaisieCoeff)
    {
        if(*SaisieCoeff != ' ')
        {
            gDonnees.coeff_init[i] = strtod(SaisieCoeff, &SaisieCoeff); //conversion caratere en nombre
            printf("%lf\n", gDonnees.coeff_init[i]);
            i++;
        }
        SaisieCoeff++;
    }
}

void BoutonOkImportMainCB(Fl_Widget* w, void* data)
{
    gInterface.FenetreImportMain->hide();
    printf("Close Import main\n");
}

void BoutonCalculNormeCB(Fl_Widget* w, void* data)
{
    CreerInterfaceNorme();
    printf("Open Norme\n");
}

void BoutonCloseNormeCB(Fl_Widget* w, void* data)
{
    gInterface.FenetreNorme->hide();
    printf("Close Norme\n");
}

void BoutonCalculProbaCB(Fl_Widget* w, void* data)
{
    CreerInterfaceProba();
    printf("Open Proba\n");
}

void BoutonCloseProbaCB(Fl_Widget* w, void* data)
{
    gInterface.FenetreProba->hide();
    printf("Close Proba\n");
}

void BoutonCalculProbaFinCB(Fl_Widget* w, void* data)
{
    CreerInterfaceProbaFin();
    printf("Open Proba\n");
    int i,j;
    for(i = 0; i < gDonnees.nbqbits*pow(2, gDonnees.nbqbits); i++)
    {
        for(j = 0; j < gDonnees.nb_colonnes; j++)
        {
            printf("%c", gDonnees.tab_op_use[i][j]); // affichage du tableau des operateurs utilises
        }
        printf("\n");
    }
}

void BoutonCloseProbaFinCB(Fl_Widget* w, void* data)
{
    gInterface.FenetreProbaFin->hide();
    printf("Close Proba\n");
}

void BoutonSaveCB(Fl_Widget* w, void* data)
{
    CreerInterfaceSave();
    printf("Open Save\n");

}

void ChampSaisieTxtCB(Fl_Widget* w, void* data)
{
    char SaisieNomFichier[80] ;
    strcpy( SaisieNomFichier, gInterface.ChampSaisieTxt->value() ) ; //recuperation nom du fichier de sauvegarde
    printf("ChampSaisieTxtCB : %s\n", SaisieNomFichier);
    sauvegarder(SaisieNomFichier);

}

void BoutonOkSaveCB(Fl_Widget* w, void* data)
{
    gInterface.FenetreSave->hide();
    printf("Close Save\n");
}

void BoutonAideCB(Fl_Widget* w, void* data)
{
    printf("Open Help\n");
    fl_message("Vous trouverez un fichier intitulé << fr_README.txt >> dans le fichier du projet");
    printf("Close Help\n");
}

void BoutonQuitterCB(Fl_Widget* w, void* data)
{
    // Fin du programme
    printf("Quit\n");
    exit(0) ;
}
