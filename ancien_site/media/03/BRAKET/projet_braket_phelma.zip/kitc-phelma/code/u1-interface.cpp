//
// u1-interface.cpp
// Declarations externes - inclusion des fichiers d'entete
// Librairies standards
#include <iostream>         // cin, cout, ...
// Programmes locaux
#include "u1-interface.h"
#include "u2-dessin.h"
#include "u3-callbacks.h"
#include "u4-fonctions.h"

// Declaration pour utiliser iostream
using namespace std;

// Definition des donnees de l'interface - structure globale de variables
struct Interface gInterface ;

// INTERFACE : NILS MALMBERG

// CreerInterface
void CreerInterface()
{
    // Creation de la fenetre principale
    gInterface.Fenetre = new Fl_Double_Window(800,600);
    gInterface.Fenetre->label("Projet Type") ;
    gInterface.Fenetre->begin() ;

    // ZONES DE DESSIN

    // Creation de la zone de dessin principale
    gInterface.ZoneDessin = new DrawingArea(X_ZONE,Y_ZONE,L_ZONE - 2*COTE + 4,H_ZONE);
    gInterface.ZoneDessin->draw_callback( ZoneDessinDessinerCB, NULL ) ;
    gInterface.ZoneDessin->mouse_callback( ZoneDessinSourisCB, NULL ) ;

    // Creation de la zone operateurs
    gInterface.ZoneOperateurs = new DrawingArea(X_ZONE + L_ZONE - 2*COTE + 8, Y_ZONE, 2*COTE + 2,H_ZONE);
    gInterface.ZoneOperateurs->draw_callback( ZoneOperateursCB, NULL ) ;
    gInterface.ZoneOperateurs->mouse_callback( ZoneOperateursSourisCB, NULL ) ;

     // Creation de la zone logo
    gInterface.ZoneLogo = new DrawingArea(X_ZONE_LOGO,Y_ZONE_LOGO,L_ZONE_LOGO,H_ZONE_LOGO);
    gInterface.ZoneLogo->draw_callback( ZoneLogoCB, NULL ) ;

    // BOUTONS ET CHAMPS DE SAISIE

    // Creation du champ de saisie du nombre de qubits
    gInterface.ChampNbQbits = new Fl_Value_Input(740, 10, 20, 20, "Nombre de Qubits : ") ;
	gInterface.ChampNbQbits->when( FL_WHEN_ENTER_KEY | FL_WHEN_RELEASE ) ;
	gInterface.ChampNbQbits->callback(ChampNbQbitsCB, NULL ) ;

    // Creation du bouton OkQbits
    gInterface.BoutonOkNbQbits = new Fl_Button(770, 10, 25, 20, "Ok") ;
    gInterface.BoutonOkNbQbits->callback( BoutonOkNbQbitsCB, NULL ) ;

    // Creation du bouton import coefficients
    gInterface.BoutonImport = new Fl_Choice(670, 50, 120, 20, "Import  |..>") ;
    gInterface.BoutonImport->add( "A la main", "", BoutonImportCB ) ;
    gInterface.BoutonImport->add( "Via fichier txt", "", BoutonImportCB ) ;

    // Creation du bouton Calcul norme
    gInterface.BoutonCalculNorme = new Fl_Button(690, 150, 100, 20, "Normalisation") ;
    gInterface.BoutonCalculNorme->callback( BoutonCalculNormeCB, NULL ) ;

    // Creation du bouton Calcul probabilites initiales
    gInterface.BoutonCalculProba = new Fl_Button(650, 190, 140, 20, "Probabilites Initiales") ;
    gInterface.BoutonCalculProba->callback( BoutonCalculProbaCB, NULL ) ;

    // Creation du bouton Calcul probabilites finales
    gInterface.BoutonCalculProbaFin = new Fl_Button(650, 230, 140, 20, "Probabilites Finales") ;
    gInterface.BoutonCalculProbaFin->callback( BoutonCalculProbaFinCB, NULL ) ;

    // Creation du bouton Save
    gInterface.BoutonSave = new Fl_Button(690, 430, 100, 20, "Save") ;
    gInterface.BoutonSave->callback( BoutonSaveCB, NULL ) ;

    // Creation du bouton Aide
    gInterface.BoutonAide = new Fl_Button(740, 570, 50, 20, "Aide") ;
    gInterface.BoutonAide->callback( BoutonAideCB, NULL ) ;

    // Creation du bouton Quitter
    gInterface.BoutonQuitter = new Fl_Button(630, 570, 100, 20, "Quitter") ;
    gInterface.BoutonQuitter->callback( BoutonQuitterCB, NULL ) ;


    // Affichage de la fenetre
    gInterface.Fenetre->end();
    gInterface.Fenetre->show();
}

void CreerInterfaceImportMain()
{
    // Creation de la fenetre principale
    gInterface.FenetreImportMain = new Fl_Double_Window(600,100);
    gInterface.FenetreImportMain->label("Import des coefficients") ;
    gInterface.FenetreImportMain->begin() ;

    // Creation du champ de saisie texte
    gInterface.ChampSaisieCoeff = new Fl_Input(250, 40, 320, 20, "Saisissez les coefficients separes \n par un espace (de la forme 0.3) :") ;
	gInterface.ChampSaisieCoeff->when( FL_WHEN_ENTER_KEY | FL_WHEN_RELEASE ) ;
	gInterface.ChampSaisieCoeff->callback(ChampSaisieCoeffCB, NULL ) ;

    // Creation du bouton Fermeture de la saisie
    gInterface.BoutonOkImportMain = new Fl_Button(300, 70, 25, 20, "Ok") ;
    gInterface.BoutonOkImportMain->callback( BoutonOkImportMainCB, NULL ) ;

    // Affichage de la fenetre
    gInterface.FenetreImportMain->end();
    gInterface.FenetreImportMain->show();
}

void CreerInterfaceProba()
{
    // Creation de la fenetre principale
    gInterface.FenetreProba = new Fl_Double_Window(700,520);
    gInterface.FenetreProba->label("Probabilites Initiales") ;
    gInterface.FenetreProba->begin() ;

    // Creation de la zone graphique
    gInterface.ZoneProba = new Fl_Chart(10,60,680,390);
    gInterface.ZoneProba->bounds(0,1);
    gInterface.ZoneProba->label("Etats");

    // Placement des etats (abscisse)
    for(int i = 0; i < pow(2,gDonnees.nbqbits); i++)
    {
        char k[15];
        if(gDonnees.nbqbits == 1)
        {
            sprintf(k, "%c%d%c", '|', gDonnees.tab_etat_base[i], '>');
        }
        else if(gDonnees.nbqbits == 2)
        {
            sprintf(k, "%c%d%d%c", '|', gDonnees.tab_etat_base[2*i], gDonnees.tab_etat_base[2*i + 1], '>');
        }
        gInterface.ZoneProba->add(pow(fabs(gDonnees.coeff_init_norme[i]),2), k, i); // affichage valeur probabilite pour l etat k
    }

    // Affichage valeur probabilites
    gInterface.TxtProba = new DrawingArea(10,10,680,45);
    gInterface.TxtProba->draw_callback(ZoneProbaCB, NULL);

    // Creation du bouton CloseProba
    gInterface.BoutonCloseProba = new Fl_Button(330, 490, 60, 20, "Close") ;
    gInterface.BoutonCloseProba->callback( BoutonCloseProbaCB, NULL ) ;

    // Affichage de la fenetre
    gInterface.FenetreProba->end();
    gInterface.FenetreProba->show();
}

void CreerInterfaceProbaFin()
{
    // Creation de la fenetre principale
    gInterface.FenetreProbaFin = new Fl_Double_Window(700,520);
    gInterface.FenetreProbaFin->label("Probabilites Finales") ;
    gInterface.FenetreProbaFin->begin() ;

    // Creation de la zone graphique
    gInterface.ZoneProbaFin = new Fl_Chart(10,60,680,390);
    gInterface.ZoneProbaFin->bounds(0,1);
    gInterface.ZoneProbaFin->label("Etats");

    double norme_carre_fin = 0;

    // Initialisation coefficients finaux au cas ou il n y a pas de portes
    int j;
    for(j = 0; j < pow(2,gDonnees.nbqbits); j++)
    {
        gDonnees.coeff_fin[j] = gDonnees.coeff_init_norme[j];
    }

    //appel de la fonction calcul modifiant gDonnees.coeff_fin
    calcul_etat_final();

    //Calcul norme
    for(j = 0; j < pow(2,gDonnees.nbqbits); j++)
    {
        norme_carre_fin += pow(gDonnees.coeff_fin[j],2);
    }

    int i;
    for(i = 0; i < pow(2,gDonnees.nbqbits); i++)
    {
        // normalisation coefficients finaux
        gDonnees.coeff_fin_norme[i] = gDonnees.coeff_fin[i]/pow(norme_carre_fin, 1.0/2);

        char k[15];

        if(gDonnees.nbqbits == 1)
        {
            sprintf(k, "%c%d%c", '|', gDonnees.tab_etat_base[i], '>');
        }
        else if(gDonnees.nbqbits == 2)
        {
            sprintf(k, "%c%d%d%c", '|', gDonnees.tab_etat_base[2*i], gDonnees.tab_etat_base[2*i + 1], '>');
        }
        gInterface.ZoneProbaFin->add(pow(fabs(gDonnees.coeff_fin_norme[i]), 2), k, i); // affichage valeur probabilite pour l etat k
    }

    // Affichage valeur probabilites
    gInterface.TxtProbaFin = new DrawingArea(10,10,680,45);
    gInterface.TxtProbaFin->draw_callback(ZoneProbaFinCB, NULL);

    // Creation du bouton CloseProba
    gInterface.BoutonCloseProbaFin = new Fl_Button(330, 490, 60, 20, "Close") ;
    gInterface.BoutonCloseProbaFin->callback( BoutonCloseProbaFinCB, NULL ) ;

    // Affichage de la fenetre
    gInterface.FenetreProbaFin->end();
    gInterface.FenetreProbaFin->show();
}

void CreerInterfaceNorme()
{
    // Creation de la fenetre principale
    gInterface.FenetreNorme = new Fl_Double_Window(700,520);
    gInterface.FenetreNorme->label("Normalisation") ;
    gInterface.FenetreNorme->begin() ;

    // Creation de la zone graphique
    gInterface.ZoneNorme = new Fl_Chart(10,60,680,390);
    gInterface.ZoneNorme->autosize();
    gInterface.ZoneNorme->label("Etats");

    // Calcul norme
    int i;
    double norme_carre = 0;
    for(i = 0; i < pow(2,gDonnees.nbqbits); i++)
    {
        norme_carre += pow((double)gDonnees.coeff_init[i],2);
    }

    for(i = 0; i < pow(2,gDonnees.nbqbits); i++)
    {
        // normalisation coefficients finaux
        gDonnees.coeff_init_norme[i] = gDonnees.coeff_init[i]/pow(norme_carre, 0.5);

        char k[15];

        if(gDonnees.nbqbits == 1)
        {
            sprintf(k, "%c%d%c", '|', gDonnees.tab_etat_base[i], '>');
        }
        else if(gDonnees.nbqbits == 2)
        {
            sprintf(k, "%c%d%d%c", '|', gDonnees.tab_etat_base[2*i], gDonnees.tab_etat_base[2*i + 1], '>');
        }
        gInterface.ZoneNorme->add(gDonnees.coeff_init_norme[i], k, i); // affichage valeur norme pour l etat k
    }

    // Affichage valeur probabilites
    gInterface.TxtNorme = new DrawingArea(10,10,680,45);
    gInterface.TxtNorme->draw_callback(ZoneNormeCB, NULL);

    // Creation du bouton CloseNorme
    gInterface.BoutonCloseNorme = new Fl_Button(330, 490, 60, 20, "Close") ;
    gInterface.BoutonCloseNorme->callback( BoutonCloseNormeCB, NULL ) ;

    // Affichage de la fenetre
    gInterface.FenetreNorme->end();
    gInterface.FenetreNorme->show();
}

void CreerInterfaceSave()
{
    // Creation de la fenetre principale
    gInterface.FenetreSave = new Fl_Double_Window(500,100);
    gInterface.FenetreSave->label("Save") ;
    gInterface.FenetreSave->begin() ;

    // Creation du champ de saisie texte
    gInterface.ChampSaisieTxt = new Fl_Input(250, 40, 200, 20, "Nom du fichier avec extension : ") ;
	gInterface.ChampSaisieTxt->when( FL_WHEN_ENTER_KEY | FL_WHEN_RELEASE ) ;
	gInterface.ChampSaisieTxt->callback(ChampSaisieTxtCB, NULL ) ;

    // Creation du bouton OkSave
    gInterface.BoutonOkSave = new Fl_Button(250, 70, 25, 20, "Ok") ;
    gInterface.BoutonOkSave->callback( BoutonOkSaveCB, NULL ) ;

    // Affichage de la fenetre
    gInterface.FenetreSave->end();
    gInterface.FenetreSave->show();
}


void ActualiserInterface()
{

}
