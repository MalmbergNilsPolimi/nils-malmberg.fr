//
// u4-fonctions.h
// Sentinelle d'inclusion
#ifndef _u4_fonctions_h
#define _u4_fonctions_h

#include "complex.h"
// Definition des constantes
#define DUREE_CYCLE 0.015    // 0.500 secondes, depend du materiel utilise

// Declaration des donnees du projet

// Structure globale pour les variables fonctionnelles
struct Donnees
{
    // Variables du projet a definir ici
    int nbqbits;
    int nb_colonnes;
    int XClic;
    int YClic;
    int flag_event;
    char op_select;
    char** tab_op_use;
    char tab_op_def[15];
    char* tab_coeff_init;
    double* coeff_init;
    double* coeff_init_norme;
    double* coeff_fin;
    double* coeff_fin_norme;
    int* tab_etat_base;
    double** v;
    double* prod;

    float** X;
    float  __complex__** Y;
    float** Z;
    float** H;
    float** S;
    float** CN;

    int ket0[2][1];
    int ket1[2][1];


};

extern struct Donnees gDonnees;

// Déclaration des sous-programmes
void InitialiserDonnees() ;

// Utilitaires

// fonctions d allocation dynamique
char* allouer_tab_char(int n) ;
int* allouer_tab_int(int n) ;
double* allouer_tab_double(int n) ;
char** allouer_mat_char_op_use() ;
int** allouer_mat_int(int n) ;
double** allouer_mat_double(int n) ;
double** allouer_matcol_double(int n) ;
float** allouer_mat_float(int n) ;
float __complex__** allouer_mat_cpxfloat(int n) ;

//fonction definissant les etats de base
void etat_de_base() ;
void etat_calcul() ;
// fonction definissant des produits
double* produit_tensoriel(double* etat1, double* etat2) ;
void produitmatriciel(int n, float** porte, double* vecteur) ;
void produitmatricielcplx(float __complex__** porte, double* vecteur) ;
// fonction pour la porte swap
void fct_swap(int i, double** vecteur) ;
// fonction permettant le calcul des coefficients finaux
void calcul_portes(double** vecteur) ;
void calcul_etat_final() ;
//fonctions en lien avec les fichiers txt
void sauvegarder(char* nom) ;
void lecture_coeff(char* nomfichier) ;

#endif // _u4_fonctions_h
