Projet BraKet - Guide d'utilisation



Le projet BraKet offre, via une interface ergonomique et simple à prendre en main, la possibilité de simuler les différentes probabilités associé à chaque composantes de chacun des états d'un ket final suite au passage d'un ket initial à travers plusieurs portes, traduit chacune par une observable (opérateur hermitique).



1. Présentation du logiciel : les différentes zones graphiques

1.1. Champ de gauche : définition du chemin

Le champ de gauche permet de définir le chemin à travers lequel un ket initial va passer. Il s'agit d'une succession de portes agissant sur le ket en entrée, et donnant en sortie un ket modifié.

1.2. Colonne au milieu : choix des portes

Au milieu de l'interface (entre les champs de droite et de gauche) se trouve une colonne avec l'ensembles des choix de porte (dans la limite de ce qui a été codé au préalable, liste non-exhaustive et modulable par ajout dans le code). La liste des portes disponibles est donné dans la partie 3.

1.3. Champ de droite : interface de gestion des données

1.3.1. Entrée : nombre de qubits et importation d'un ket initial

Le champ de droite offre dans sa partie supérieure l'opportunité de sélectionner le nombre de qubits pour les kets à étudier par un champ prenant un entier naturel en argument (dans notre cas, seuls les kets codés sur un ou deux qubits sont étudiés). Le bouton "Import" permet d'importer un ket initial, au choix tapé à la main ou importé à partir d'un fichier texte.
ATTENTION : le bon nombre de qubits doit impérativement être sélectionné par l'utilisateur. Les kets codés sur n qubits possèdent 2^n coefficients.

1.3.2. Sortie

En dessous de la partie de gestion de l'entrée se trouve la partie gestion de la sortie. Tout d'abord, le bouton "Normalisation" donne sous forme d'un diagramme de barres les coefficients normalisés du ket en entrée. Ensuite, le bouton "Probabilités Initiales" donne sous la forme d'un diagramme de barres les probabilités du ket initial. Enfin, le bouton "Probabilités Finales" donne sous forme d'un diagramme de barres également les probabilités du ket en sortie des portes.

1.3.3. Gestion fichier

Un bouton "Save" est ensuite mis à disposition pour sauvegarder dans un fichier texte :
 - sur une première ligne les coefficients du ket initial
 - sur une deuxième ligne les probabilités du ket initial
 - sur une troisième ligne les probabilités du ket en sortie.
Un bouton "Aide" est ensuite mis à disposition pour ouvrir le fichier "fr_README.pdf". Une version anglaise est aussi disponible ("en_README.pdf"). Enfin, le bouton "Quitter" permet de quitter le logiciel.



2. Prise en main du logiciel

2.1. Quelques règles à suivre 

2.1.1. Règle 1

Il est important pour définir le chemin sur le champ de gauche de d'abord cliquer sur l'une des cases de ce même champ, puis de sélectionner l'une des portes disponibles sur la colonne centrale.

2.1.2. Règle 2

Aussi, comme avertit précédemment en 1.3.1, il faut impérativement sélectionner le bon nombre de qubits pour l'étude souhaitée, et travailler en conséquence avec le bon nombre de coefficients associés.

2.1.3. Règle 3

Sur la fenêtre de gauche, une seule porte contrôle peut être imposée à chaque colonne. Cependant, plusieurs portes peuvent être conditionnées par cette même porte contrôle.

2.2. Etapes de manipulation

2.2.1. Import du ket initial

Tout d'abord, sélectionner le nombre de qubits sur lequel sera codé le ket. Importer un ket via l'une des deux méthodes, à la main ou sur un fichier texte. Les 2^n coefficients doivent être séparé d'un espace " ", et ils sont rangés dans l'ordre croissant du ket associé (le premier coefficient est celui correspondant à |00>, le deuxième à |01> etc...).

2.2.2. Normalisation

Normaliser ensuite le ket initial à l'aide du bouton "Normaliser". Une fenêtre apparaît alors pour visualiser cette normalisation, et les données du ket initial normalisé sont stockées.

2.2.3. Calcul du ket initial normalisé

Calculer ensuite les probabilités du ket initial grâce au bouton "Probabilités Initiales". Le programme stocke alors les probabiltés associées à chacun des coefficients composant le ket initial (carré de chacun des modules). Une fenêtre s'ouvre alors pour représenter les probabilités pour le ket final d'être dans un état.

2.2.4. Calcul du ket final

Lancer ensuite le processus de calcul du ket final, en cliquant sur le bouton "Probabilités Finales". Le programme stocke alors les probabiltés associées à chacun des coefficients composant le ket final (carré de chacun des modules). Une fenêtre s'ouvre alors pour représenter les probabilités pour le ket final d'être dans un état.

2.2.5. Sauvegarde

Cliquer ensuite sur le bouton "Save". Une fenêtre s'ouvre alors. Entrer dans le champ prévu à cet effet le nom du fichier en sorti, accompagné de l'extension (".txt" convient bien). Le programme crée alors un fichier texte contenant sur la première ligne les coefficients du ket initial normalisé, sur la deuxième ligne les coefficients du ket final normalisé, et sur la troisième ligne les probabilités de chacune des composantes du ket final. Le document texte est situé dans le dossier projet.



3. Liste des portes

3.1. Porte Pauli-X/NOT (X)

La porte Pauli-X, aussi appelée porte NOT (notée "X" sur l'interface) traduit un opérateur "NOT", transformant les kets |0> pour les changer en |1> et vice-versa.

3.2. Porte Pauli-Y (Y) (non opérationnelle)

La porte Pauli-Y (notée "Y" sur l'interface) agit sur les kets |0> pour les transformer en i|1>, et sur les kets |1> pour les transformer en -i|0>.

3.3. Porte Pauli-Z (Z)

La porte Pauli-Z (notée "Z" sur l'interface) maintient les kets |0>, et transforme les kets |1> en leur opposé -|1>.

3.4. Porte Hadamard (H)

La porte Hadmard (notée "H" sur l'interface) transforme les kets |0> en (|0> + |1>)/srqt(2), et les kets |1> en (|0> - |1>)/srqt(2).

3.5. Porte Swap (S)

La porte Swap (notée "S" sur l'interface) intervertit les qubits représentés dans la base des 2-qubits |00>, |01>, |10>, |11>. Par exemple, le ket |00> reste |00>, et le ket |01> est transformé en ket |10>.

3.6. Porte CNOT (NOT)

La porte CNOT (notée "NOT" sur l'interface) agit comme une porte Pauli-X/NOT sur le deuxième qubit des kets représentés dans la base des 2-qubits {(|ij>) | i,j appartenant à {0,1}} dans la condition suivante : si le premier qubit i est 1, le deuxième qubit est modifié (|0> en |1>, |1> en |0>). Par exemple, le ket |01> reste le ket |01>, mais le ket |10> est transformé en ket |11>.

3.7. Porte Toffoli (T) (non applicable ici, car utilisée pour des kets codés sur 3 qubits)

La porte Toffoli (notée "T" sur l'interface) agit comme une porte Pauli-X/NOT sur le troisième qubit des kets représentés dans la base des 3-qubits {(|ijk>) | i,j,k appartenant à {0,1}} dans la condition suivante : si les deux premiers qubits i et j sont 1, le troisième qubit est modifié (|0> en |1>, |1> en |0>). Par exemple, le ket |101> reste le ket |101>, mais le ket |110> est transformé en ket |111>.

3.8. Porte contrôle (•) (non codée ici)

La porte contrôle (notée "•" sur l'interface) combinée à une autre porte (le plus souvent X, Y ou Z, et alors respectivement abrégée cX, cY ou cZ) agit sur le qubit où cette seconde porte est appliquée dans le cas où le qubit de la porte de contrôle est |1>. Par exemple, le ket |01> passant dans la porte cX (porte • combinée avec la porte Pauli-X) reste |01>, le ket |11> devient |10>.



4. Description brève du code

4.1. Variables globales

L'ensemble des variables globales du projet sont réunies au sein d'une structure, appelée gDonnees. Elle contient entre autres les noms (un caractère) et les fonctions (des matrices de tailles 2×2 ou 3×3) de chacune des portes. Le nombre de qubits choisis est stocké dans l'attribut "nbqbits" de la structure "gDonnees" et sert à de très nombreuses reprises pour la taille des tableaux de stockage de données. Cette structure gère également les coefficients initiaux et finaux des kets mis en jeu.

4.2. Données

Tout d'abord, les données sont initialisées grâce à la fonction de type void "InitialiserDonnees()". Cette fonction permet la gestion de l'allocation dynamique des différents tableaux (dont ceux contenant les matrices de chacune des observables ou encore ceux contenant les données initiales des kets et après passages dans les portes). Les états sont ensuite définis pour les kets mis en jeu pendant la simulation via la fonction de type void "etat_de_base()", qui se réfère au nombre de qubits choisis (via l'attribut "nbqbits" de la structure "gDonnees").

4.3. Calcul

Le calcul du ket en sortie des portes est ensuite géré par la fonction de type void "calcul_etat_final()". Les coefficients en sortie sont ensuite stockées dans "gDonnees", accessibles via l'attribut "coeff_fin".