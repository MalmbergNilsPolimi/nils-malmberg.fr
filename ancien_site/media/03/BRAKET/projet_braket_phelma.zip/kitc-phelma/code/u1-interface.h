//
// u1-interface.h
// Sentinelle d'inclusion
#ifndef _u1_interface_h
#define _u1_interface_h

// Declarations externes - inclusion des fichiers d'entete
#include "main.h"
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Value_Output.H>
#include <FL/Fl_Output.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Round_Button.H>
#include <FL/Fl_Value_Slider.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Value_Input.H>
//#include <FL/FL_ask.H>
#include <FL/fl_draw.H>
#include <FL/Fl_Chart.H>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

// Definition des constantes
#define X_ZONE  10      // X de la zone
#define Y_ZONE  10      // Y de la zone
#define L_ZONE  570     // Largeur de la zone
#define H_ZONE  580     // Hauteur de la zone

#define X_ZONE_LOGO  610      // X de la zone
#define Y_ZONE_LOGO  480      // Y de la zone
#define L_ZONE_LOGO  300     // Largeur de la zone
#define H_ZONE_LOGO  300    // Hauteur de la zone


// Declaration des objets de l'interface
struct Interface
{
    // Creation des fenetres
    Fl_Double_Window*   Fenetre ;
    Fl_Double_Window*   FenetreImportMain;
    Fl_Double_Window*   FenetreProba;
    Fl_Double_Window*   FenetreProbaFin;
    Fl_Double_Window*   FenetreNorme;
    Fl_Double_Window*   FenetreSave ;

    // Creation des zones de dessin
    DrawingArea*        ZoneDessin ;
    DrawingArea*        ZoneLogo;
    DrawingArea*        ZoneOperateurs;
    DrawingArea*        TxtProba;
    DrawingArea*        TxtProbaFin;
    DrawingArea*        TxtNorme;

    // Creation zones graphiques
    Fl_Chart*           ZoneProba;
    Fl_Chart*           ZoneProbaFin;
    Fl_Chart*           ZoneNorme;

    // Champs Qbits
    Fl_Value_Input*     ChampNbQbits;
    Fl_Button*          BoutonOkNbQbits;

    // Champs import coefficients
    Fl_Choice*          BoutonImport ;
    Fl_Input*           ChampSaisieCoeff;
    Fl_Button*          BoutonOkImportMain;

    // Calcul norme
    Fl_Button*          BoutonCalculNorme ;
    Fl_Button*          BoutonCloseNorme;

    // Calcul probabilites
    Fl_Button*          BoutonCalculProba ;
    Fl_Button*          BoutonCloseProba;
    Fl_Button*          BoutonCalculProbaFin ;
    Fl_Button*          BoutonCloseProbaFin;

    // Sauvegarde
    Fl_Button*          BoutonSave ;
    Fl_Input*           ChampSaisieTxt ;
    Fl_Button*          BoutonOkSave;

    // Bouttons aide et quitter
    Fl_Button*          BoutonAide;
    Fl_Button*          BoutonQuitter ;

} ;

// Declaration des objets de l'interface generale - ne pas supprimer
extern struct Interface gInterface ;


// Declaration des sous-programmes
void CreerInterface(); // interface generale
void CreerInterfaceImportMain(); // interface import coefficients main
void CreerInterfaceNorme(); // interface graphique norme
void CreerInterfaceProba(); // interface graphique probabilites initiales
void CreerInterfaceProbaFin(); // interface graphique probabilites finales
void CreerInterfaceSave(); // interface sauvegarde


void ActualiserInterface();

#endif // _u1_interface_h
