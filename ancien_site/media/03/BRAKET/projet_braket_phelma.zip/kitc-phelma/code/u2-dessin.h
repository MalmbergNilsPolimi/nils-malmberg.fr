//
// u2-dessin.h
// Sentinelle d'inclusion
#ifndef _u2_dessin_h
#define _u2_dessin_h

#define COTE 30
#define RAYON 8

// Declaration des sous-programmes
void ZoneDessinDessinerCB( Fl_Widget* widget, void* data ) ;
void ZoneOperateursCB( Fl_Widget* w, void* data) ;
void ZoneProbaCB(Fl_Widget* w, void* data) ;
void ZoneProbaFinCB(Fl_Widget* w, void* data) ;
void ZoneNormeCB(Fl_Widget* w, void* data) ;
void ZoneLogoCB( Fl_Widget* widget, void* data ) ;
void ChoisirOperateur(int Operateur) ;


#endif // _u2_dessin_h
